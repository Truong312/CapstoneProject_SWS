﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SWS.ApiCore.Auth;
using SWS.BusinessObjects.DTOs;
using SWS.Services.ImportOrders;

namespace SWS.ApiCore.Controllers
{
    [ApiController]
    [Route("api/import-orders")]
    [Authorize(Policy = "StaffOnly")] // only role "1"
    public class ImportOrdersCommandController : ControllerBase
    {
        private readonly IImportOrderCommandService _cmd;

        public ImportOrdersCommandController(IImportOrderCommandService cmd)
        {
            _cmd = cmd;
        }

        /// <summary>
        /// Create Import Order (status = Pending)
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateImportOrderRequest req)
        {
            var staffUserId = ClaimUtils.GetUserIdOrThrow(User);

            try
            {
                var result = await _cmd.CreateAsync(req, staffUserId);
                return CreatedAtAction(
                    actionName: nameof(GetDetailForCreatedRedirect),
                    routeValues: new { id = result.ImportOrderId },
                    value: new { isSuccess = true, statusCode = 201, data = result }
                );
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { isSuccess = false, statusCode = 400, message = ex.Message });
            }
        }

        // Chỉ để CreatedAtAction có route — bạn đã có GET detail ở controller Query
        [HttpGet("{id:int}/created-redirect")]
        public IActionResult GetDetailForCreatedRedirect([FromRoute] int id) => NoContent();
    }
   

}
