﻿using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SWS.ApiCore.Controllers
{
    [ApiController]
    [Route("api/debug")]
    public class DebugAuthController : ControllerBase
    {
        /// <summary>
        /// Echo lại Authorization header để kiểm tra Swagger có gửi token không
        /// </summary>
        [HttpGet("echo")]
        [AllowAnonymous]
        public IActionResult Echo([FromHeader(Name = "Authorization")] string? authorization)
        {
            return Ok(new
            {
                Authorization = authorization ?? "<null>",
                HasBearerPrefix = (authorization ?? "").StartsWith("Bearer ")
            });
        }

        /// <summary>
        /// Trả về các claim trong token (cần Authorize)
        /// </summary>
        [HttpGet("me")]
        [Authorize]
        public IActionResult Me()
        {
            var claims = User.Claims.Select(c => new { c.Type, c.Value });
            return Ok(claims);
        }
    }
}
