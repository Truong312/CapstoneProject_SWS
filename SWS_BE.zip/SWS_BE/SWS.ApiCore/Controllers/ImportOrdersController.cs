﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SWS.Services.ImportOrders;

namespace SWS.ApiCore.Controllers
{
    [ApiController]
    [Route("api/import-orders")]
    [Authorize(Policy = "StaffOrManager")] // role "1" or "2"
    public class ImportOrdersController : ControllerBase
    {
        private readonly IImportOrderQueryService _svc;
        public ImportOrdersController(IImportOrderQueryService svc) => _svc = svc;

        [HttpGet]
        public async Task<IActionResult> GetList(
            [FromQuery] string? from,
            [FromQuery] string? to,
            [FromQuery] string? status,
            [FromQuery] int? providerId,
            [FromQuery] string? invoiceLike,
            [FromQuery] int? createdBy)
        {
            var fromDate = TryParseDateOnly(from);
            var toDate = TryParseDateOnly(to);

            if (from is not null && fromDate is null)
                return BadRequest(new { isSuccess = false, statusCode = 400, message = "Invalid format. Expected yyyy-MM-dd for 'from'." });

            if (to is not null && toDate is null)
                return BadRequest(new { isSuccess = false, statusCode = 400, message = "Invalid format. Expected yyyy-MM-dd for 'to'." });

            if (fromDate.HasValue && toDate.HasValue && fromDate > toDate)
                return BadRequest(new { isSuccess = false, statusCode = 400, message = "Invalid format. Expected from <= to." });

            var data = await _svc.GetListAsync(fromDate, toDate, status, providerId, invoiceLike, createdBy);
            return Ok(new { isSuccess = true, statusCode = 200, total = data.Count, data });
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetDetail([FromRoute] int id)
        {
            var dto = await _svc.GetDetailAsync(id);
            if (dto == null)
                return NotFound(new { isSuccess = false, statusCode = 404, message = "Import order not found" });

            return Ok(new { isSuccess = true, statusCode = 200, data = dto });
        }

        private static DateOnly? TryParseDateOnly(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            return DateOnly.TryParse(s, out var d) ? d : null;
        }
    }
}
