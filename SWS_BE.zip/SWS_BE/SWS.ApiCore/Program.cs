﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authorization;
using SWS.ApiCore.Extensions;
using AppBackend.Extensions;
using SWS.BusinessObjects.AppSettings;

// Return lookups / orders (đã có sẵn)
using SWS.Repositories.Repositories.ReturnRepo;
using SWS.Services.ReturnLookups;
using SWS.Services.ReturnOrders;

// Import Orders (mới thêm)
using SWS.Repositories.Repositories.ImportOrders;
using SWS.Services.ImportOrders;

var builder = WebApplication.CreateBuilder(args);

// ================== Services & Configs ==================
builder.Services.AddCloudinaryConfig(builder.Configuration);
builder.Services.AddAutoMapperConfig();
builder.Services.AddDbConfig(builder.Configuration);       // cấu hình DbContext (SQL Server)
builder.Services.AddCorsConfig();                          // đăng ký policy "AllowAllOrigins"
builder.Services.AddSwaggerConfig();
builder.Services.AddDefaultAuth(builder.Configuration);    // JWT auth (đã có)

// Optional login with google
// builder.Services.AddGoogleAuth(builder.Configuration);

builder.Services.AddSessionConfig();
builder.Services.AddHttpContextAccessor();
builder.Services.AddRateLimitConfig();                     // rate limiting

// Memory Cache (nếu các service có dùng)
builder.Services.AddMemoryCache();

// Đăng ký các application services khác (booking, queue, cache, ...)
builder.Services.AddServicesConfig();

// Controllers + Json options (tránh vòng tham chiếu)
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    });

// Bind app settings
builder.Services.Configure<GoogleAuthSettings>(builder.Configuration.GetSection("GoogleAuthSettings"));

// ========== Authorization Policies (theo claim 'role') ==========
builder.Services.AddAuthorization(options =>
{
    // Chỉ Staff (role = "1") được phép tạo Import Order
    options.AddPolicy("StaffOnly", policy =>
        policy.RequireClaim("role", "1"));

    // Staff hoặc Manager (role = "1" hoặc "2") được xem danh sách/chi tiết
    options.AddPolicy("StaffOrManager", policy =>
        policy.RequireAssertion(ctx =>
            ctx.User.HasClaim(c => c.Type == "role" && (c.Value == "1" || c.Value == "2"))));
});

// ========== DI: Return Lookups / Return Orders ==========
builder.Services.AddScoped<IReturnReasonRepository, ReturnReasonRepository>();
builder.Services.AddScoped<IReturnStatusRepository, ReturnStatusRepository>();
builder.Services.AddScoped<IReturnOrderQueryRepository, ReturnOrderQueryRepository>();

builder.Services.AddScoped<IReturnLookupService, ReturnLookupService>();
builder.Services.AddScoped<IReturnOrderQueryService, ReturnOrderQueryService>();

// ========== DI: Import Orders (List/Detail + Create) ==========
builder.Services.AddScoped<IImportOrderQueryRepository, ImportOrderQueryRepository>();
builder.Services.AddScoped<IImportOrderQueryService, ImportOrderQueryService>();
builder.Services.AddScoped<IImportOrderCommandService, ImportOrderCommandService>();

// ================== Build App ==================
var app = builder.Build();

// ================== Middleware Pipeline ==================
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRateLimiter();

// Bật CORS đúng tên policy đã đăng ký trong AddCorsConfig()
app.UseCors("AllowAllOrigins");

// HTTPS có thể tắt khi dev cổng http, nếu cần thì mở:
// app.UseHttpsRedirection();

app.UseSession();

app.UseAuthentication();   // phải trước UseAuthorization
app.UseAuthorization();

app.MapControllers();

app.Run();
