﻿using System.ComponentModel.DataAnnotations;

namespace SWS.BusinessObjects.DTOs
{
    public class CreateImportOrderLineRequest : IValidatableObject
    {
        [Range(1, int.MaxValue, ErrorMessage = "Invalid format. Expected ProductId > 0.")]
        public int ProductId { get; set; }

        [Range(1, 1_000_000, ErrorMessage = "Invalid format. Expected Quantity between 1 and 1000000.")]
        public int Quantity { get; set; }

        [Range(0, 1_000_000_000, ErrorMessage = "Invalid format. Expected ImportPrice >= 0.")]
        public decimal? ImportPrice { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            yield break;
        }
    }

    public class CreateImportOrderRequest : IValidatableObject
    {
        [Range(1, int.MaxValue, ErrorMessage = "Invalid format. Expected ProviderId > 0.")]
        public int ProviderId { get; set; }

        [RegularExpression(@"^[A-Z0-9\-]{3,30}$",
            ErrorMessage = "Invalid format. Expected InvoiceNumber to match ^[A-Z0-9\\-]{3,30}$.")]
        public string? InvoiceNumber { get; set; }

        public DateOnly? OrderDate { get; set; }

        [StringLength(255, ErrorMessage = "Invalid format. Expected Description length <= 255.")]
        public string? Description { get; set; }

        [MinLength(1, ErrorMessage = "Invalid format. Expected at least 1 item.")]
        public List<CreateImportOrderLineRequest> Items { get; set; } = new();

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var dup = Items.GroupBy(i => i.ProductId).FirstOrDefault(g => g.Count() > 1);
            if (dup != null)
            {
                yield return new ValidationResult(
                    "Invalid format. Expected unique ProductId per order.",
                    new[] { nameof(Items) });
            }

            if (OrderDate.HasValue && OrderDate.Value > DateOnly.FromDateTime(DateTime.UtcNow.AddDays(7)))
            {
                yield return new ValidationResult(
                    "Invalid format. Expected OrderDate <= Today + 7 days.",
                    new[] { nameof(OrderDate) });
            }
        }
    }

    public class CreateImportOrderResult
    {
        public int ImportOrderId { get; set; }
        public string Status { get; set; } = "Pending";
        public string InvoiceNumber { get; set; } = "";
    }
}
