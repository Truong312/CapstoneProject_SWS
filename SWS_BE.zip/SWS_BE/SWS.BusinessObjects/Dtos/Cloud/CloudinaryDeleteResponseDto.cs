namespace SWS.BusinessObjects.Dtos;

public class CloudinaryDeleteResponseDto
{
    public string PublicId { get; set; }
    public string Status { get; set; }  
}