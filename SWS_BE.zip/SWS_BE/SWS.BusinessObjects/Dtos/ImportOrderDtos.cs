﻿// DTOs dùng cho màn danh sách + chi tiết Import Order.
namespace SWS.BusinessObjects.DTOs
{
    // Item hiển thị ở danh sách
    public record ImportOrderListItemDto(
        int ImportOrderId,
        string InvoiceNumber,
        DateOnly OrderDate,
        string? Status,
        string ProviderName,
        string? CreatedByName,
        int TotalLines,
        int TotalQuantity
    );

    // Item dòng ở chi tiết
    public record ImportOrderLineDto(
        int ImportDetailId,
        int ProductId,
        string ProductName,
        int Quantity,
        decimal? ImportPrice
    );

    // Gói dữ liệu trả về cho màn chi tiết
    public class ImportOrderDetailDto
    {
        public ImportOrderListItemDto Header { get; set; } = default!;
        public List<ImportOrderLineDto> Lines { get; set; } = new();
    }
}
