﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWS.BusinessObjects.TimeCoreHelper
{
    public static class TimeSystem
    {
        public static DateTime SystemTimeNow => DateTime.UtcNow;
    }
}
