﻿using SWS.BusinessObjects.Models;

namespace SWS.Repositories.Repositories.ImportOrders
{
    public interface IImportOrderQueryRepository
    {
        Task<List<ImportOrder>> GetListAsync(
            DateOnly? from, DateOnly? to, string? status,
            int? providerId, string? invoiceLike, int? createdBy);

        Task<ImportOrder?> GetDetailAsync(int id);
    }
}
