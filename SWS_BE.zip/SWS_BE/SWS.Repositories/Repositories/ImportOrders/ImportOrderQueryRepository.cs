﻿using Microsoft.EntityFrameworkCore;
using SWS.BusinessObjects.Models;

namespace SWS.Repositories.Repositories.ImportOrders
{
    public class ImportOrderQueryRepository : IImportOrderQueryRepository
    {
        private readonly SmartWarehouseDbContext _ctx;
        public ImportOrderQueryRepository(SmartWarehouseDbContext ctx) => _ctx = ctx;

        public async Task<List<ImportOrder>> GetListAsync(
            DateOnly? from, DateOnly? to, string? status,
            int? providerId, string? invoiceLike, int? createdBy)
        {
            var q = _ctx.ImportOrders
                .Include(o => o.Provider)
                .Include(o => o.CreatedByNavigation)
                .Include(o => o.ImportDetails)
                .AsQueryable();

            if (from.HasValue) q = q.Where(o => o.OrderDate >= from.Value);
            if (to.HasValue) q = q.Where(o => o.OrderDate <= to.Value);
            if (!string.IsNullOrWhiteSpace(status)) q = q.Where(o => o.Status == status);
            if (providerId.HasValue) q = q.Where(o => o.ProviderId == providerId.Value);

            if (!string.IsNullOrWhiteSpace(invoiceLike))
            {
                invoiceLike = invoiceLike.Trim();
                q = q.Where(o => o.InvoiceNumber.Contains(invoiceLike));
            }

            if (createdBy.HasValue) q = q.Where(o => o.CreatedBy == createdBy.Value);

            return await q.OrderByDescending(o => o.OrderDate)
                          .ThenByDescending(o => o.ImportOrderId)
                          .ToListAsync();
        }

        public Task<ImportOrder?> GetDetailAsync(int id)
            => _ctx.ImportOrders
                   .Include(o => o.Provider)
                   .Include(o => o.CreatedByNavigation)
                   .Include(o => o.ImportDetails)
                        .ThenInclude(d => d.Product)
                   .FirstOrDefaultAsync(o => o.ImportOrderId == id);
    }
}
