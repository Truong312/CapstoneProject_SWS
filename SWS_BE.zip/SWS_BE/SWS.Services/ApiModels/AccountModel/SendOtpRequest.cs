namespace SWS.Services.ApiModels
{
    public class SendOtpRequest
    {
        public string Email { get; set; }
    }
}
