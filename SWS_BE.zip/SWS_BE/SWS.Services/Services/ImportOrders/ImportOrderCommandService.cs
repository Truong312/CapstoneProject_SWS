﻿using Microsoft.EntityFrameworkCore;
using SWS.BusinessObjects.DTOs;
using SWS.BusinessObjects.Models;
using SWS.Services.Shared;

namespace SWS.Services.ImportOrders
{
    public interface IImportOrderCommandService
    {
        Task<CreateImportOrderResult> CreateAsync(CreateImportOrderRequest req, int staffUserId);
    }

    public class ImportOrderCommandService : IImportOrderCommandService
    {
        private readonly SmartWarehouseDbContext _ctx;
        public ImportOrderCommandService(SmartWarehouseDbContext ctx) => _ctx = ctx;

        public async Task<CreateImportOrderResult> CreateAsync(CreateImportOrderRequest req, int staffUserId)
        {
            if (req.ProviderId <= 0)
                throw ValidationMessages.Invalid("ProviderId > 0");
            if (req.Items == null || req.Items.Count == 0)
                throw ValidationMessages.Invalid("at least 1 line item");
            if (req.Items.Any(i => i.ProductId <= 0))
                throw ValidationMessages.Invalid("ProductId > 0");
            if (req.Items.Any(i => i.Quantity <= 0))
                throw ValidationMessages.Invalid("Quantity > 0");

            // Provider phải tồn tại và Type = "Provider"
            var provider = await _ctx.BusinessPartners
                .FirstOrDefaultAsync(p => p.PartnerId == req.ProviderId && p.Type == "Provider");
            if (provider == null)
                throw ValidationMessages.Invalid("valid ProviderId (existing Provider)");

            // Tất cả ProductId phải tồn tại
            var productIds = req.Items.Select(i => i.ProductId).Distinct().ToList();
            var existProductIds = await _ctx.Products
                .Where(p => productIds.Contains(p.ProductId))
                .Select(p => p.ProductId)
                .ToListAsync();
            if (existProductIds.Count != productIds.Count)
                throw ValidationMessages.Invalid("all ProductId must exist");

            var nowDate = DateOnly.FromDateTime(DateTime.UtcNow);

            var order = new ImportOrder
            {
                ProviderId = req.ProviderId,
                InvoiceNumber = string.IsNullOrWhiteSpace(req.InvoiceNumber)
                    ? $"IMP-{DateTime.UtcNow:yyyyMMddHHmmss}"
                    : req.InvoiceNumber.Trim().ToUpperInvariant(),
                OrderDate = req.OrderDate ?? nowDate,
                CreatedDate = nowDate,
                Status = "Pending",
                // Description = req.Description,   <-- BỎ DÒNG NÀY vì ImportOrder không có property Description
                CreatedBy = staffUserId
            };

            foreach (var line in req.Items)
            {
                order.ImportDetails.Add(new ImportDetail
                {
                    ProductId = line.ProductId,
                    Quantity = line.Quantity,
                    ImportPrice = line.ImportPrice
                });
            }

            _ctx.ImportOrders.Add(order);
            await _ctx.SaveChangesAsync();

            _ctx.ActionLogs.Add(new ActionLog
            {
                UserId = staffUserId,
                ActionType = "Create",
                EntityType = "ImportOrder",
                Timestamp = DateTime.UtcNow,
                Description = $"Create ImportOrder #{order.ImportOrderId} (Pending)"
            });
            await _ctx.SaveChangesAsync();

            return new CreateImportOrderResult
            {
                ImportOrderId = order.ImportOrderId,
                Status = order.Status!,
                InvoiceNumber = order.InvoiceNumber
            };
        }
    }
}
