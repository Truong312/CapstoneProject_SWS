﻿using SWS.BusinessObjects.DTOs;
using SWS.Repositories.Repositories.ImportOrders;

namespace SWS.Services.ImportOrders
{
    public interface IImportOrderQueryService
    {
        Task<List<ImportOrderListItemDto>> GetListAsync(
            DateOnly? from, DateOnly? to, string? status,
            int? providerId, string? invoiceLike, int? createdBy);

        Task<ImportOrderDetailDto?> GetDetailAsync(int id);
    }

    public class ImportOrderQueryService : IImportOrderQueryService
    {
        private readonly IImportOrderQueryRepository _repo;
        public ImportOrderQueryService(IImportOrderQueryRepository repo) => _repo = repo;

        public async Task<List<ImportOrderListItemDto>> GetListAsync(
            DateOnly? from, DateOnly? to, string? status,
            int? providerId, string? invoiceLike, int? createdBy)
        {
            var list = await _repo.GetListAsync(from, to, status, providerId, invoiceLike, createdBy);

            return list.Select(o => new ImportOrderListItemDto(
                ImportOrderId: o.ImportOrderId,
                InvoiceNumber: o.InvoiceNumber,
                OrderDate: o.OrderDate,
                Status: o.Status,
                ProviderName: o.Provider.Name,
                CreatedByName: o.CreatedByNavigation?.FullName,
                TotalLines: o.ImportDetails.Count,
                TotalQuantity: o.ImportDetails.Sum(d => d.Quantity)
            )).ToList();
        }

        public async Task<ImportOrderDetailDto?> GetDetailAsync(int id)
        {
            var o = await _repo.GetDetailAsync(id);
            if (o == null) return null;

            var header = new ImportOrderListItemDto(
                ImportOrderId: o.ImportOrderId,
                InvoiceNumber: o.InvoiceNumber,
                OrderDate: o.OrderDate,
                Status: o.Status,
                ProviderName: o.Provider.Name,
                CreatedByName: o.CreatedByNavigation?.FullName,
                TotalLines: o.ImportDetails.Count,
                TotalQuantity: o.ImportDetails.Sum(d => d.Quantity)
            );

            var lines = o.ImportDetails.Select(d => new ImportOrderLineDto(
                ImportDetailId: d.ImportDetailId,
                ProductId: d.ProductId,
                ProductName: d.Product.Name,
                Quantity: d.Quantity,
                ImportPrice: d.ImportPrice
            )).ToList();

            return new ImportOrderDetailDto { Header = header, Lines = lines };
        }
    }
}
